### 1. THÔNG TIN SINH VIÊN 
- Họ tên: Nguyễn Quang Phát
- MSSV: 24120117

### 2. Biên dịch chương trình 
```Bash
$ g++ -std=c++23 main.cpp -o main
```

``` Bash
$ ./main
```