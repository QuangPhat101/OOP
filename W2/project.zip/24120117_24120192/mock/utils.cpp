#include "../lib/utils.h"

int calcSum(int start, int end) {
   return 0;
}