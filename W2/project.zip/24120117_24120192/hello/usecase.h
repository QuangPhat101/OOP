#pragma once // TODO: chuyển qua include guard
#include <iostream>
#include <string>
using std::cout, std::cin;

void salute(std::string message);
void bye();
void findNextDayUseCase();
bool checkDayMonthYear(int d, int m, int y);
