#include "usecase.h"

int main()
{
    salute("Chương trình kiểm tra ngày hợp lệ và in ra ngày kế tiếp\n");

    findNextDayUseCase(); // Siêu rút gọn của clean architecture

    bye();

    return 0;
}
