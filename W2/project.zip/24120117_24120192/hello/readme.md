## Thông tin sinh viên 1 ##
MSSV: **24120076**  
Họ và tên: *Nguyễn Đức Anh Khôi*  
## Thông tin sinh viên 2 ##  
MSSV: **24120117**  
Họ và tên: *Nguyễn Quang Phát*
## Thông tin sinh viên 3 ##
MSSV: **24120192**  
Họ và tên: *Trần Nguyễn Quốc Khánh*

## Biên dịch & chạy
```Bash
$ cd hello 
```

```Bash
$ g++ -std=c++23 *.cpp ../lib/*.cpp -o ./out/app
```

```Bash
$ ./out/app
```