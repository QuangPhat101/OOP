## Thông tin sinh viên 
MSSV: **24120117**  
Tên: **Nguyễn Quang Phát**
##

## Biên dịch chương trình 
```Bash
$ g++ -std=c++23 main.cpp -o ./out/app
```

```Bash
$ ./out/app
```
