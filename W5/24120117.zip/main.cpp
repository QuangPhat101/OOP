#include <iostream>
#include <print>
#include <memory>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <regex>
#include <format>
#include <expected>
using std::cout, std::cin;
using std::expected, std::unexpected;
using std::format;
using std::ifstream, std::cerr;
using std::istream, std::ostream;
using std::regex, std::smatch;
using std::string;
using std::stringstream, std::ostringstream;
using std::vector;

void salute(const string &, const string &);
void bye();

class Employee
{
private:
    string _name;
    int _days;
    long long _paidPerDay;

public:
    string getName() const;
    int getDays() const;
    int getPaid() const;
    void setName(const string &s);
    void setDays(const int &days);
    void setPaid(const int &paid);

public:
    Employee();
    Employee(string name, int days, int paidPerDay);
};

class EmployeeDecorator
{
private:
    Employee _info;
    long long _salary;

public:
    long long getSalary() const;
    Employee getInfo() const;

public:
    EmployeeDecorator(Employee info, long long s);

public:
    friend class RowConverter;
};

string formatSalary(const long long &a);
class App
{
public:
    vector<Employee> readEmployeeFromFile(string input);
    vector<EmployeeDecorator> calcSalary(const vector<Employee> &Employ);
    string createReport(const vector<EmployeeDecorator> infos);
};

class File
{
public:
    static vector<string> readAllLines(string input);
};

class EmployeeParser
{
public:
    expected<Employee, string> parse(const string info);
};

class RowConverter
{
public:
    string convert(const EmployeeDecorator &info);
};

class TableConverter
{
public:
    string convert(const vector<EmployeeDecorator> &infos);
};
int main()
{
    string input = "SalaryJune.txt";
    salute("Chương trình tính lương nhân viên", input);
    App app;
    vector<Employee> Employees = app.readEmployeeFromFile(input);
    vector<EmployeeDecorator> infos = app.calcSalary(Employees);
    string report = app.createReport(infos);
    cout << "Bảng lương nhân viên\n";
    cout << "STT  |" << format(" {0:<15} | {1:<8} | {2:<15} | {3:<12} |", "Nhân viên", "Số ngày", "Lương ngày", "Lương tháng");
    cout << "\n--------------------------------------------------------------------\n"
         << report<<"\n";
    bye();
    return 0;
}
void salute(const string &name, const string &file)
{
    cout << name << "\n\n";
    cout << "Đang đọc thông tin từ tập tin " << file << "...\n";
    cout << "Đã xong!\n\n";
}

void bye()
{
    cout << "Chương trình đang thoát. Bấm enter để kết thúc...";
    cin.ignore(1);
}

Employee::Employee()
{
    this->_days = 0;
    this->_paidPerDay = 0;
    this->_name = "";
}

Employee::Employee(string name, int days, int paidPerDay)
{
    this->_name = name;
    this->_days = days;
    this->_paidPerDay = paidPerDay;
}

string Employee::getName() const { return this->_name; }

int Employee::getDays() const { return this->_days; }

int Employee::getPaid() const { return this->_paidPerDay; }

void Employee::setName(const string &s) { this->_name = s; }

void Employee::setDays(const int &days) { this->_days = days; }

void Employee::setPaid(const int &paid) { this->_paidPerDay = paid; }

long long EmployeeDecorator::getSalary() const
{
    return this->_salary;
}

Employee EmployeeDecorator::getInfo() const
{
    return this->_info;
}

EmployeeDecorator::EmployeeDecorator(Employee info, long long s)
{
    this->_info = info;
    this->_salary = s;
}

vector<Employee> App::readEmployeeFromFile(string input)
{
    vector<Employee> result;
    vector<string> lines = File::readAllLines(input);

    EmployeeParser parser;
    for (auto &line : lines)
    {
        auto check = parser.parse(line);
        if (check)
        {
            Employee item = *check;
            result.push_back(item);
        }
        else
            return result;
    }
    return result;
}
string formatSalary(const long long &a)
{
    string tmp;
    int count = 0;
    long long A = a;
    while (A != 0)
    {
        int number = A % 10;
        tmp.push_back(number + '0');
        A /= 10;
        count++;
        if (count == 3)
        {
            tmp.push_back('.');
            count = 0;
        }
    }
    if (tmp[tmp.size() - 1] == '.')
        tmp.pop_back();
    string res;
    for (int i = tmp.size() - 1; i >= 0; i--)
    {
        res.push_back(tmp[i]);
    }
    return res;
}

vector<EmployeeDecorator> App::calcSalary(const vector<Employee> &employ)
{
    vector<EmployeeDecorator> result;
    for (const auto &emp : employ)
    {
        long long salary = emp.getDays() * emp.getPaid();
        EmployeeDecorator temp(emp, salary);
        result.push_back(temp);
    }
    return result;
}

string App::createReport(const vector<EmployeeDecorator> infos)
{
    ostringstream builder;
    TableConverter converter;
    builder << converter.convert(infos) << "\n";
    long long finalSalary = 0;
    for (const auto &info : infos)
    {
        finalSalary += info.getSalary();
    }
    builder << format("Số lượng nhân viên: {}\n", infos.size());
    builder << format("Tổng lương: {}\n", formatSalary(finalSalary));
    return builder.str();
}

vector<string> File::readAllLines(string input)
{
    ifstream reader;
    reader.open(input);
    if (reader.fail())
    {
        cerr << format("Cannot open input file: {}\n", input);
        exit(1);
    }
    vector<string> result;
    string line;
    while (!reader.eof())
    {
        getline(reader, line);
        result.push_back(line);
    }
    reader.close();
    return result;
}
expected<Employee, string> EmployeeParser::parse(const string info)
{
    regex pattern("Employee Name=(\\w+), Days=(\\d+), PaidPerDay=(\\d+)");
    smatch matches;
    bool matched = regex_search(info, matches, pattern);
    if (!matched)
        return unexpected("Invalid format");
    string name = matches[1];
    int day = stoi(matches[2]);
    int paidPerDay = stoi(matches[3]);
    Employee result(name, day, paidPerDay);
    return result;
}
string RowConverter::convert(const EmployeeDecorator &info)
{
    Employee res = info.getInfo();
    string result = format(
        " {0:<15} | {1:<8} | {2:<15} | {3:<12} |",
        res.getName(), res.getDays(),
        formatSalary(res.getPaid()), formatSalary(info.getSalary()));
    return result;
}
string TableConverter::convert(const vector<EmployeeDecorator> &infos)
{
    stringstream builder;
    RowConverter converter;
    int count = 1;
    for (auto const &info : infos)
    {

        builder << count << "    |" << converter.convert(info) << "\n";
        count++;
    }
    return builder.str();
}