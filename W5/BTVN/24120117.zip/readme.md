MSSV: **24120117**  
Tên: **Nguyễn Quang Phát**

```Bash
$ g++ -std=c++23 main01.cpp Exercise3/utils.cpp -o ./out/app
$ ./out/app
```

```Bash
$ g++ -std=c++23 main02.cpp Exercise3/utils.cpp -o ./out/app
$ ./out/app
```

