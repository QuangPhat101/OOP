#include "SharedVector.h"

int main()
{
    SharedVector a;
    update1(a);
    return 0;
}
