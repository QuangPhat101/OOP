## Thông tin sinh viên
MSSV: **24120076**  
Tên: **Nguyễn Đức Anh Khôi**

MSSV: **24120117**  
Tên: **Nguyễn Quang Phát**

MSSV: **24120158**  
Tên: **Phan Tấn Vượng**

MSSV: **24120192**  
Tên: **Trần Nguyễn Quốc Khánh**

## Biên dịch chương trình

```Bash
$ g++ -std=c++23 main.cpp function.cpp -o ./out/app
```

```Bash
$ ./out/app
```