var searchData=
[
  ['calcsumfractions_0',['CalcSumFractions',['../namespacebus.html#a2e867c56f6278c966d7f1e9c1aa34492',1,'bus']]]
];
