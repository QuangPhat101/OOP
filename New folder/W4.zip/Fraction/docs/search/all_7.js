var searchData=
[
  ['salute_0',['salute',['../main_8cpp.html#a96b0ab1b4e07a0692d301766ef2018a9',1,'main.cpp']]],
  ['setdenominator_1',['setDenominator',['../classFraction.html#af30475c1c9806ea9b04dbd4d21cee049',1,'Fraction']]],
  ['setnumerator_2',['setNumerator',['../classFraction.html#a21686ce5e47b00053983b16cb2fc28f1',1,'Fraction']]]
];
