var searchData=
[
  ['readme_0',['readme',['../md_readme.html',1,'']]],
  ['readme_2emd_1',['readme.md',['../readme_8md.html',1,'']]],
  ['requestfraction_2',['requestFraction',['../namespaceui.html#ac83c6a058a4c68248720098a232f5813',1,'ui']]]
];
