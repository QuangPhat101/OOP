var searchData=
[
  ['calcsumfractionsusecase_0',['CalcSumFractionsUseCase',['../classCalcSumFractionsUseCase.html',1,'']]]
];
