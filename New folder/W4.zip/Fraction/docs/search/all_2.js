var searchData=
[
  ['execute_0',['execute',['../classCalcSumFractionsUseCase.html#a801a3f93db825d4a17bd3362ef5359a2',1,'CalcSumFractionsUseCase']]]
];
