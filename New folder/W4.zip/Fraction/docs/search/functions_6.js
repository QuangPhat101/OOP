var searchData=
[
  ['requestfraction_0',['requestFraction',['../namespaceui.html#ac83c6a058a4c68248720098a232f5813',1,'ui']]]
];
