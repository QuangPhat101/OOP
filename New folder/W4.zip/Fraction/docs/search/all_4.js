var searchData=
[
  ['getdenominator_0',['getDenominator',['../classFraction.html#a9c83b2aea3cdfa2c1ac3e5fb5d9c9bab',1,'Fraction']]],
  ['getminimalistfractions_1',['getMinimalistFractions',['../namespacebus.html#a2dece8f3ffded71046f691f400917e6a',1,'bus']]],
  ['getnumerator_2',['getNumerator',['../classFraction.html#abb8d8691dec7dac04b095cdf587fe7de',1,'Fraction']]]
];
