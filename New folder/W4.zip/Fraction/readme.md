MSSV: **24120117**  
Tên: **Nguyễn Quang Phát**

```Bash
$ g++ -std=c++23 main.cpp bus/*.cpp dto/*.cpp ui/*.cpp usecase/*.cpp -o ./out/app
```

```Bash
$ ./out/app
```